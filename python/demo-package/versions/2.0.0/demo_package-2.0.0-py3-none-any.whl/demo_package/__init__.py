__version__ = "2.0.0"

def hello():
    return "Hello from demo-package 2.0.0"