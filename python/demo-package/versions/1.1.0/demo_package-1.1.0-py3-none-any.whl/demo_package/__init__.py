__version__ = "1.1.0"

def hello():
    return "Hello from demo-package 1.1.0"